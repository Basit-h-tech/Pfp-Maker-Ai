'use client';

import { useState } from 'react';
import { Search, Copy, Check } from 'lucide-react';
import promptsData from '@/data/prompts-clean.json';

const categories = ['All', 'Human', 'Cyberpunk', 'Anime', 'Product', 'Fantasy', 'Design', 'Space', 'Abstract'];

export default function PromptsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredPrompts = promptsData.filter((prompt) => {
    const matchesSearch = 
      prompt.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prompt.prompt.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || prompt.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const copyPrompt = async (id: string, text: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const modelColors: Record<string, string> = {
    'Nano Banana': 'bg-yellow-100 text-yellow-700',
    'FLUX': 'bg-blue-100 text-blue-700',
    'Stable Diffusion': 'bg-green-100 text-green-700',
    'Midjourney': 'bg-purple-100 text-purple-700',
    'GPT Image': 'bg-pink-100 text-pink-700',
    'Ideogram': 'bg-orange-100 text-orange-700',
    'Recraft': 'bg-teal-100 text-teal-700',
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="border-b border-gray-200 bg-white sticky top-20 z-30">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">AI Prompt Library</h1>
          
          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search prompts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
            />
          </div>

          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
                  selectedCategory === category
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Prompt Grid */}
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredPrompts.map((prompt) => (
            <div
              key={prompt.id}
              className="bg-white border border-gray-200 rounded-2xl p-6 hover:shadow-lg hover:border-purple-300 transition-all group"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="font-semibold text-lg text-gray-900 mb-2 group-hover:text-purple-600 transition-colors">
                    {prompt.title}
                  </h3>
                  <span
                    className={`inline-block px-3 py-1 rounded-lg text-sm font-medium ${
                      modelColors[prompt.model] || 'bg-gray-100 text-gray-700'
                    }`}
                  >
                    {prompt.model}
                  </span>
                </div>
              </div>

              {/* Prompt Preview */}
              <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-3">
                {prompt.prompt}
              </p>

              {/* Copy Button */}
              <button
                onClick={() => copyPrompt(prompt.id, prompt.prompt)}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-medium transition-colors"
              >
                {copiedId === prompt.id ? (
                  <>
                    <Check className="w-5 h-5" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-5 h-5" />
                    Copy Prompt
                  </>
                )}
              </button>
            </div>
          ))}
        </div>

        {/* No Results */}
        {filteredPrompts.length === 0 && (
          <div className="text-center py-20">
            <p className="text-gray-500 text-lg">No prompts found</p>
          </div>
        )}
      </div>
    </div>
  );
}
