'use client';

import { Check, Sparkles, Zap, Crown } from 'lucide-react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';

export default function PricingPage() {
  const plans = [
    {
      name: 'Free',
      price: '$0',
      period: 'forever',
      icon: Sparkles,
      gradient: 'from-gray-600 to-gray-700',
      features: [
        'Access to 1000+ prompts',
        'Basic templates',
        '500+ wallpapers',
        'AI PFP Studio (Basic)',
        'Standard quality exports',
        'Community support',
      ],
      cta: 'Get Started',
      popular: false,
    },
    {
      name: 'Pro',
      price: '$9',
      period: 'per month',
      icon: Zap,
      gradient: 'from-purple-600 to-purple-700',
      features: [
        'Access to 5000+ prompts',
        'All premium templates',
        '1000+ wallpapers',
        'AI PFP Studio (Advanced)',
        'HD quality exports',
        'Priority support',
        'Custom collections',
        'Advanced filters',
      ],
      cta: 'Start Pro Trial',
      popular: true,
    },
    {
      name: 'Enterprise',
      price: 'Custom',
      period: 'contact us',
      icon: Crown,
      gradient: 'from-orange-600 to-red-600',
      features: [
        'Unlimited prompts',
        'All templates + custom',
        'Unlimited wallpapers',
        'AI PFP Studio (Enterprise)',
        '4K quality exports',
        'Dedicated support',
        'Team collaboration',
        'API access',
        'Custom branding',
      ],
      cta: 'Contact Sales',
      popular: false,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Simple, <span className="text-gradient">Transparent Pricing</span>
          </h1>
          <p className="text-xl text-gray-600">
            Choose the perfect plan for your creative needs. Start free, upgrade anytime.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-16">
          {plans.map((plan, index) => {
            const Icon = plan.icon;
            return (
              <Card
                key={plan.name}
                hover
                className={`relative ${
                  plan.popular ? 'ring-2 ring-purple-600 shadow-premium-lg' : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <span className="px-4 py-1 bg-gradient-to-r from-purple-600 to-purple-700 text-white text-sm font-bold rounded-full shadow-lg">
                      Most Popular
                    </span>
                  </div>
                )}

                <div className="text-center mb-6">
                  <div
                    className={`inline-flex w-16 h-16 bg-gradient-to-br ${plan.gradient} rounded-2xl items-center justify-center mb-4 shadow-lg`}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <div className="mb-2">
                    <span className="text-5xl font-bold">{plan.price}</span>
                    {plan.price !== 'Custom' && <span className="text-gray-600">/{plan.period.split(' ')[1] || 'mo'}</span>}
                  </div>
                  <p className="text-gray-600">{plan.period}</p>
                </div>

                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start space-x-3">
                      <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  variant={plan.popular ? 'primary' : 'outline'}
                  className="w-full"
                  size="lg"
                >
                  {plan.cta}
                </Button>
              </Card>
            );
          })}
        </div>

        {/* FAQ */}
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {[
              {
                q: 'Can I upgrade or downgrade anytime?',
                a: 'Yes! You can change your plan at any time. Upgrades take effect immediately, and downgrades apply at the next billing cycle.',
              },
              {
                q: 'Is there a free trial for Pro?',
                a: 'Yes, we offer a 14-day free trial for the Pro plan. No credit card required.',
              },
              {
                q: 'What payment methods do you accept?',
                a: 'We accept all major credit cards, PayPal, and other popular payment methods.',
              },
              {
                q: 'Can I cancel anytime?',
                a: 'Absolutely. You can cancel your subscription at any time with no penalties or fees.',
              },
            ].map((faq, index) => (
              <Card key={index} hover>
                <h3 className="font-bold mb-2">{faq.q}</h3>
                <p className="text-gray-600">{faq.a}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
