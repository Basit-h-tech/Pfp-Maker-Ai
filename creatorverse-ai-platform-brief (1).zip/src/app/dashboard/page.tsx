'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, Download, Image, Sparkles, FileText, Wallpaper } from 'lucide-react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Link from 'next/link';
import {
  getFavoritePrompts,
  getFavoriteWallpapers,
  getFavoriteTemplates,
  getEditorProjects,
  getDownloadHistory,
} from '@/lib/storage';
import type { SavedPrompt, SavedWallpaper, SavedTemplate, EditorProject } from '@/lib/storage';

export default function DashboardPage() {
  const [favoritePrompts, setFavoritePrompts] = useState<SavedPrompt[]>([]);
  const [favoriteWallpapers, setFavoriteWallpapers] = useState<SavedWallpaper[]>([]);
  const [favoriteTemplates, setFavoriteTemplates] = useState<SavedTemplate[]>([]);
  const [projects, setProjects] = useState<EditorProject[]>([]);
  const [downloads, setDownloads] = useState<any[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const prompts = await getFavoritePrompts();
    const wallpapers = await getFavoriteWallpapers();
    const templates = await getFavoriteTemplates();
    const userProjects = await getEditorProjects();
    const downloadHistory = await getDownloadHistory();

    setFavoritePrompts(prompts);
    setFavoriteWallpapers(wallpapers);
    setFavoriteTemplates(templates);
    setProjects(userProjects);
    setDownloads(downloadHistory);
  };

  const stats = [
    {
      label: 'Saved Prompts',
      value: favoritePrompts.length,
      icon: Sparkles,
      color: 'from-purple-500 to-pink-500',
    },
    {
      label: 'Saved Wallpapers',
      value: favoriteWallpapers.length,
      icon: Wallpaper,
      color: 'from-blue-500 to-cyan-500',
    },
    {
      label: 'Saved Templates',
      value: favoriteTemplates.length,
      icon: FileText,
      color: 'from-green-500 to-emerald-500',
    },
    {
      label: 'Total Downloads',
      value: downloads.length,
      icon: Download,
      color: 'from-orange-500 to-red-500',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="text-5xl font-bold mb-4">
            Your <span className="text-gradient">Dashboard</span>
          </h1>
          <p className="text-xl text-gray-600">Manage your creative projects and favorites</p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card hover className="relative overflow-hidden">
                  <div
                    className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${stat.color} opacity-10 rounded-full -mr-8 -mt-8`}
                  />
                  <div className="relative">
                    <Icon className={`w-10 h-10 mb-4 bg-gradient-to-br ${stat.color} bg-clip-text text-transparent`} />
                    <div className="text-4xl font-bold text-gradient mb-2">{stat.value}</div>
                    <div className="text-gray-600 font-medium">{stat.label}</div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-12"
        >
          <h2 className="text-3xl font-bold mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Link href="/pfp-studio">
              <Card hover className="text-center cursor-pointer group">
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-purple-600 to-purple-700 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Image className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-lg mb-2">Create PFP</h3>
                <p className="text-sm text-gray-600">Design AI profile pictures</p>
              </Card>
            </Link>
            <Link href="/prompts">
              <Card hover className="text-center cursor-pointer group">
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-lg mb-2">Browse Prompts</h3>
                <p className="text-sm text-gray-600">Discover AI prompts</p>
              </Card>
            </Link>
            <Link href="/wallpapers">
              <Card hover className="text-center cursor-pointer group">
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-green-600 to-green-700 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Wallpaper className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-lg mb-2">Get Wallpapers</h3>
                <p className="text-sm text-gray-600">Download 4K wallpapers</p>
              </Card>
            </Link>
            <Link href="/templates">
              <Card hover className="text-center cursor-pointer group">
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-orange-600 to-orange-700 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <FileText className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-lg mb-2">Use Templates</h3>
                <p className="text-sm text-gray-600">Professional designs</p>
              </Card>
            </Link>
          </div>
        </motion.div>

        {/* Recent Favorites */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <h2 className="text-3xl font-bold mb-6">Recent Favorites</h2>
          {favoritePrompts.length === 0 && favoriteWallpapers.length === 0 && favoriteTemplates.length === 0 ? (
            <Card className="text-center py-12">
              <Heart className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-xl font-bold mb-2">No favorites yet</h3>
              <p className="text-gray-600 mb-6">Start exploring and save your favorite items</p>
              <Link href="/prompts">
                <Button>Browse Prompts</Button>
              </Link>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {favoritePrompts.slice(0, 3).map((prompt) => (
                <Card key={prompt.id} hover>
                  <div className="flex items-center space-x-3 mb-3">
                    <Sparkles className="w-5 h-5 text-purple-600" />
                    <span className="text-sm font-medium text-purple-600">Prompt</span>
                  </div>
                  <h3 className="font-bold mb-2">{prompt.title}</h3>
                  <p className="text-sm text-gray-600 line-clamp-2">{prompt.prompt}</p>
                </Card>
              ))}
              {favoriteWallpapers.slice(0, 3).map((wallpaper) => (
                <Card key={wallpaper.id} hover>
                  <div className="flex items-center space-x-3 mb-3">
                    <Wallpaper className="w-5 h-5 text-blue-600" />
                    <span className="text-sm font-medium text-blue-600">Wallpaper</span>
                  </div>
                  <h3 className="font-bold mb-2">{wallpaper.title}</h3>
                  <p className="text-sm text-gray-600">{wallpaper.category}</p>
                </Card>
              ))}
              {favoriteTemplates.slice(0, 3).map((template) => (
                <Card key={template.id} hover>
                  <div className="flex items-center space-x-3 mb-3">
                    <FileText className="w-5 h-5 text-green-600" />
                    <span className="text-sm font-medium text-green-600">Template</span>
                  </div>
                  <h3 className="font-bold mb-2">{template.title}</h3>
                  <p className="text-sm text-gray-600">{template.category}</p>
                </Card>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
