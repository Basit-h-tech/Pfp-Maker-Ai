'use client';

import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  Upload,
  Download,
  Undo2,
  Redo2,
  ZoomIn,
  ZoomOut,
  Sparkles,
  Image as ImageIcon,
  Palette,
  Frame,
  Type,
  Circle,
  Square,
} from 'lucide-react';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';

const categories = [
  { id: 'upload', label: 'Upload', icon: Upload },
  { id: 'backgrounds', label: 'Backgrounds', icon: ImageIcon },
  { id: 'colors', label: 'Colors', icon: Palette },
  { id: 'frames', label: 'Frames', icon: Frame },
  { id: 'shapes', label: 'Shapes', icon: Circle },
  { id: 'text', label: 'Text', icon: Type },
];

const backgrounds = [
  { id: 1, name: 'Purple Gradient', color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' },
  { id: 2, name: 'Blue Sky', color: 'linear-gradient(135deg, #48c6ef 0%, #6f86d6 100%)' },
  { id: 3, name: 'Sunset', color: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)' },
  { id: 4, name: 'Ocean', color: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)' },
  { id: 5, name: 'Forest', color: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)' },
  { id: 6, name: 'Sunset Orange', color: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)' },
  { id: 7, name: 'Dark Night', color: 'linear-gradient(135deg, #2c3e50 0%, #000000 100%)' },
  { id: 8, name: 'Pink Dream', color: 'linear-gradient(135deg, #e96443 0%, #904e95 100%)' },
];

const solidColors = [
  '#FFFFFF', '#000000', '#7C3AED', '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6',
  '#EC4899', '#06B6D4', '#84CC16', '#F97316',
];

export default function PFPStudioPage() {
  const [activeCategory, setActiveCategory] = useState('upload');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [backgroundColor, setBackgroundColor] = useState('#7C3AED');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setUploadedImage(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleExport = () => {
    // In a real app, this would export the canvas
    alert('Export functionality would generate the final image here');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Toolbar */}
      <div className="sticky top-20 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-6 h-6 text-purple-600" />
              <h1 className="text-xl font-bold">AI Profile Picture Studio</h1>
            </div>

            <div className="flex items-center space-x-2">
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="Undo">
                <Undo2 className="w-5 h-5" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="Redo">
                <Redo2 className="w-5 h-5" />
              </button>
              <div className="w-px h-6 bg-gray-300 mx-2" />
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="Zoom In">
                <ZoomIn className="w-5 h-5" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors" title="Zoom Out">
                <ZoomOut className="w-5 h-5" />
              </button>
              <div className="w-px h-6 bg-gray-300 mx-2" />
              <Button onClick={handleExport}>
                <Download className="w-5 h-5 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-12 gap-6">
          {/* Left Sidebar */}
          <div className="col-span-12 lg:col-span-2">
            <Card className="p-3">
              <div className="space-y-2">
                {categories.map((category) => {
                  const Icon = category.icon;
                  return (
                    <button
                      key={category.id}
                      onClick={() => setActiveCategory(category.id)}
                      className={`w-full flex flex-col items-center justify-center p-4 rounded-xl transition-all ${
                        activeCategory === category.id
                          ? 'bg-purple-600 text-white shadow-lg'
                          : 'hover:bg-gray-100 text-gray-700'
                      }`}
                    >
                      <Icon className="w-6 h-6 mb-2" />
                      <span className="text-sm font-medium">{category.label}</span>
                    </button>
                  );
                })}
              </div>
            </Card>
          </div>

          {/* Canvas Area */}
          <div className="col-span-12 lg:col-span-7">
            <Card className="p-8">
              <div className="flex items-center justify-center min-h-[600px]">
                <div
                  className="relative w-full max-w-lg aspect-square rounded-3xl shadow-premium-lg overflow-hidden"
                  style={{ background: backgroundColor }}
                >
                  {uploadedImage ? (
                    <img
                      src={uploadedImage}
                      alt="Uploaded"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-white/80">
                      <Upload className="w-20 h-20 mb-4" />
                      <p className="text-xl font-medium">Upload an image to get started</p>
                      <p className="text-sm mt-2">or choose a template from the sidebar</p>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          </div>

          {/* Right Sidebar */}
          <div className="col-span-12 lg:col-span-3">
            <Card className="p-6">
              <h3 className="font-bold text-lg mb-4">
                {categories.find(c => c.id === activeCategory)?.label}
              </h3>

              {activeCategory === 'upload' && (
                <div className="space-y-4">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full"
                  >
                    <Upload className="w-5 h-5 mr-2" />
                    Choose Image
                  </Button>
                  <p className="text-sm text-gray-600 text-center">
                    Supports PNG, JPG, WEBP
                  </p>
                </div>
              )}

              {activeCategory === 'backgrounds' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    {backgrounds.map((bg) => (
                      <button
                        key={bg.id}
                        onClick={() => setBackgroundColor(bg.color)}
                        className="aspect-square rounded-xl shadow-md hover:shadow-lg transition-all hover:scale-105"
                        style={{ background: bg.color }}
                        title={bg.name}
                      />
                    ))}
                  </div>
                </div>
              )}

              {activeCategory === 'colors' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-4 gap-3">
                    {solidColors.map((color) => (
                      <button
                        key={color}
                        onClick={() => setBackgroundColor(color)}
                        className="aspect-square rounded-xl shadow-md hover:shadow-lg transition-all hover:scale-105 border-2 border-gray-200"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              )}

              {activeCategory === 'frames' && (
                <div className="text-center py-8 text-gray-500">
                  <Frame className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Frame options coming soon</p>
                </div>
              )}

              {activeCategory === 'shapes' && (
                <div className="text-center py-8 text-gray-500">
                  <Circle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Shape tools coming soon</p>
                </div>
              )}

              {activeCategory === 'text' && (
                <div className="text-center py-8 text-gray-500">
                  <Type className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Text editor coming soon</p>
                </div>
              )}
            </Card>

            {/* Preview Modes */}
            <Card className="p-6 mt-6">
              <h3 className="font-bold text-lg mb-4">Preview</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600 mb-2">Circle</p>
                  <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-gray-200">
                    <div
                      className="w-full h-full"
                      style={{ background: backgroundColor }}
                    >
                      {uploadedImage && (
                        <img src={uploadedImage} alt="Preview" className="w-full h-full object-cover" />
                      )}
                    </div>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-2">Square</p>
                  <div className="w-24 h-24 rounded-xl overflow-hidden border-2 border-gray-200">
                    <div
                      className="w-full h-full"
                      style={{ background: backgroundColor }}
                    >
                      {uploadedImage && (
                        <img src={uploadedImage} alt="Preview" className="w-full h-full object-cover" />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
