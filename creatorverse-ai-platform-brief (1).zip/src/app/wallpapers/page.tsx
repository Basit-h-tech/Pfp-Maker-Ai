'use client';

import { useState } from 'react';
import { Search, Download, Heart } from 'lucide-react';
import wallpapersData from '@/data/wallpapers-clean.json';

const categories = ['All', 'Cyberpunk', 'Gaming', 'Nature', 'Cars', 'Space', 'Minimal', 'Sports'];

export default function WallpapersPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  const filteredWallpapers = wallpapersData.filter((wallpaper) => {
    const matchesSearch = wallpaper.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || wallpaper.category === selectedCategory;
    return matchesSearch && matchesCategory && wallpaper.imageUrl; // Only show if image exists
  });

  const toggleFavorite = (id: string) => {
    const newFavorites = new Set(favorites);
    if (newFavorites.has(id)) {
      newFavorites.delete(id);
    } else {
      newFavorites.add(id);
    }
    setFavorites(newFavorites);
  };

  const handleDownload = (imageUrl: string, title: string) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = title.toLowerCase().replace(/\s/g, '-') + '.jpg';
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="border-b border-gray-200 bg-white sticky top-20 z-30">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">Wallpaper Library</h1>
          
          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search wallpapers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
            />
          </div>

          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
                  selectedCategory === category
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Masonry Grid */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="columns-1 md:columns-2 lg:columns-3 xl:columns-4 gap-6 space-y-6">
          {filteredWallpapers.map((wallpaper) => (
            <div
              key={wallpaper.id}
              className="break-inside-avoid group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300"
            >
              {/* Image */}
              <div className="relative overflow-hidden">
                <img
                  src={wallpaper.imageUrl}
                  alt={wallpaper.title}
                  className="w-full h-auto group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
                
                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                  <button
                    onClick={() => handleDownload(wallpaper.imageUrl, wallpaper.title)}
                    className="p-3 bg-white rounded-full hover:bg-gray-100 transition-colors"
                    title="Download"
                  >
                    <Download className="w-5 h-5 text-gray-900" />
                  </button>
                  <button
                    onClick={() => toggleFavorite(wallpaper.id)}
                    className="p-3 bg-white rounded-full hover:bg-gray-100 transition-colors"
                    title="Favorite"
                  >
                    <Heart
                      className={`w-5 h-5 ${
                        favorites.has(wallpaper.id)
                          ? 'fill-red-500 text-red-500'
                          : 'text-gray-900'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Card Info */}
              <div className="p-4">
                <h3 className="font-semibold text-gray-900 mb-1">{wallpaper.title}</h3>
                <span className="inline-block px-3 py-1 bg-purple-100 text-purple-700 text-sm font-medium rounded-lg">
                  {wallpaper.category}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* No Results */}
        {filteredWallpapers.length === 0 && (
          <div className="text-center py-20">
            <p className="text-gray-500 text-lg">No wallpapers found</p>
          </div>
        )}
      </div>
    </div>
  );
}
