'use client';

import { useState, useRef, useCallback, useEffect } from 'react';
import { Upload, Download, RotateCcw, X, Sparkles, Camera, Clipboard, Check, ArrowDown } from 'lucide-react';
import { categories, type Preset } from '@/data/pfp-presets';

export default function PFPStudioPage() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [selectedPreset, setSelectedPreset] = useState<Preset | null>(null);
  const [visibleCategories, setVisibleCategories] = useState(6);
  const [isDragging, setIsDragging] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 600) {
        setVisibleCategories((prev) => Math.min(prev + 3, categories.length));
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleFile = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setUploadedImage(result);
      setSelectedPreset(null);
      const img = new Image();
      img.onload = () => { imageRef.current = img; };
      img.src = result;
    };
    reader.readAsDataURL(file);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handlePaste = useCallback(() => {
    navigator.clipboard.read().then(async (items) => {
      for (const item of items) {
        for (const type of item.types) {
          if (type.startsWith('image/')) {
            const blob = await item.getType(type);
            handleFile(new File([blob], 'pasted.png', { type }));
            return;
          }
        }
      }
    }).catch(() => {
      alert('Paste not supported in this browser. Please use the upload button.');
    });
  }, [handleFile]);

  const handleDownload = async () => {
    if (!imageRef.current || !selectedPreset) return;
    setIsDownloading(true);
    try {
      const img = imageRef.current;
      const canvas = document.createElement('canvas');
      const size = 1024;
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const minDim = Math.min(img.width, img.height);
      const sx = (img.width - minDim) / 2;
      const sy = (img.height - minDim) / 2;
      ctx.filter = selectedPreset.filter;
      ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, size, size);
      if (selectedPreset.overlay && selectedPreset.overlayOpacity) {
        ctx.filter = 'none';
        ctx.globalCompositeOperation = (selectedPreset.mixBlendMode as GlobalCompositeOperation) || 'multiply';
        ctx.globalAlpha = selectedPreset.overlayOpacity;
        ctx.fillStyle = selectedPreset.overlay;
        ctx.fillRect(0, 0, size, size);
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = 'source-over';
      }
      if (selectedPreset.vignette) {
        ctx.filter = 'none';
        const gradient = ctx.createRadialGradient(size / 2, size / 2, size * 0.3, size / 2, size / 2, size * 0.7);
        gradient.addColorStop(0, 'rgba(0,0,0,0)');
        gradient.addColorStop(1, 'rgba(0,0,0,0.5)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, size, size);
      }
      const link = document.createElement('a');
      link.download = `pfp-${selectedPreset.name.toLowerCase().replace(/\s/g, '-')}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch {
      alert('Download failed. Try uploading the image again.');
    } finally {
      setIsDownloading(false);
    }
  };

  const resetAll = () => {
    setUploadedImage(null);
    setSelectedPreset(null);
    imageRef.current = null;
    setVisibleCategories(6);
  };

  const totalPresets = categories.reduce((acc, cat) => acc + cat.presets.length, 0);

  if (!uploadedImage) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        <div className="max-w-lg w-full">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-purple-50 text-purple-700 rounded-full font-semibold text-sm mb-8 border border-purple-100">
              <Sparkles className="w-4 h-4" />
              Profile Picture Studio
            </div>
            <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 mb-5 leading-[1.1] tracking-tight">
              Upload Your<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600">Photo</span>
            </h1>
            <p className="text-lg text-gray-400 max-w-md mx-auto">
              Then choose from {totalPresets}+ styles across {categories.length} categories
            </p>
          </div>

          <div
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`relative border-2 border-dashed rounded-3xl p-14 text-center transition-all duration-300 cursor-pointer group ${
              isDragging ? 'border-purple-500 bg-purple-50 scale-[1.01]' : 'border-gray-200 hover:border-purple-400 hover:bg-purple-50/30'
            }`}
          >
            <input ref={fileInputRef} type="file" accept="image/png,image/jpeg,image/webp" onChange={(e) => { if (e.target.files?.[0]) handleFile(e.target.files[0]); }} className="hidden" />
            <div className={`w-20 h-20 mx-auto mb-6 rounded-2xl flex items-center justify-center transition-all duration-300 ${isDragging ? 'bg-purple-600' : 'bg-purple-100 group-hover:bg-purple-200'}`}>
              <Upload className={`w-10 h-10 transition-colors ${isDragging ? 'text-white' : 'text-purple-600'}`} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">{isDragging ? 'Drop it here!' : 'Drop your photo here'}</h3>
            <p className="text-gray-400 mb-6">or click to browse files</p>
            <div className="flex gap-2 justify-center">
              {['PNG', 'JPG', 'WEBP'].map((fmt) => (
                <span key={fmt} className="px-3 py-1 bg-gray-100 text-gray-500 rounded-lg text-xs font-bold tracking-wide">{fmt}</span>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 mt-4">
            <button onClick={(e) => { e.stopPropagation(); handlePaste(); }} className="flex items-center justify-center gap-2 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-gray-700 font-semibold hover:bg-gray-100 transition-colors">
              <Clipboard className="w-4 h-4" /> Paste Image
            </button>
            <button onClick={(e) => { e.stopPropagation(); const demoImg = new Image(); demoImg.crossOrigin = 'anonymous'; demoImg.onload = () => { imageRef.current = demoImg; setUploadedImage(demoImg.src); }; demoImg.src = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80'; }} className="flex items-center justify-center gap-2 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-gray-700 font-semibold hover:bg-gray-100 transition-colors">
              <Camera className="w-4 h-4" /> Try Demo
            </button>
          </div>
        </div>
      </div>
    );
  }

  const currentFilter = selectedPreset?.filter || 'none';
  const currentOverlay = selectedPreset?.overlay;
  const currentOverlayOpacity = selectedPreset?.overlayOpacity;
  const currentMixBlend = selectedPreset?.mixBlendMode;
  const currentVignette = selectedPreset?.vignette;
  const currentBorderRadius = selectedPreset?.borderRadius;
  const currentBorder = selectedPreset?.border;

  return (
    <div className="min-h-screen bg-[#FAFAFA]">
      {/* Sticky Header */}
      <div className="sticky top-[72px] z-40 bg-white/95 backdrop-blur-sm border-b border-gray-100">
        <div className="max-w-[1400px] mx-auto px-6 py-3.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-purple-600 rounded-lg flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div className="hidden sm:block">
                <h2 className="font-bold text-gray-900 text-sm leading-tight">PFP Studio</h2>
                <p className="text-xs text-gray-400">{selectedPreset ? `Style: ${selectedPreset.name}` : 'Select a style below'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={resetAll} className="flex items-center gap-1.5 px-3.5 py-2 border border-gray-200 rounded-xl text-gray-600 text-sm font-medium hover:bg-gray-50 transition-colors">
                <RotateCcw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">New Photo</span>
              </button>
              {selectedPreset && (
                <button onClick={handleDownload} disabled={isDownloading} className="flex items-center gap-1.5 px-5 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-purple-400 text-white rounded-xl text-sm font-semibold shadow-md shadow-purple-600/25 transition-colors">
                  {isDownloading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Download className="w-4 h-4" />}
                  <span className="hidden sm:inline">{isDownloading ? 'Saving...' : 'Download PFP'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-[1400px] mx-auto px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Preview */}
          <div className="lg:w-[280px] flex-shrink-0">
            <div className="lg:sticky lg:top-[140px]">
              <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Preview</h3>
                  {selectedPreset && (
                    <button onClick={() => setSelectedPreset(null)} className="flex items-center gap-1 text-xs text-gray-400 hover:text-red-500 transition-colors">
                      <X className="w-3 h-3" /> Clear
                    </button>
                  )}
                </div>

                {/* Main Preview */}
                <div className="relative w-full aspect-square overflow-hidden bg-gray-100 mb-5" style={{ borderRadius: currentBorderRadius || '20px', border: currentBorder || 'none' }}>
                  <img src={uploadedImage} alt="Preview" className="w-full h-full object-cover" style={{ filter: currentFilter }} />
                  {currentOverlay && <div className="absolute inset-0" style={{ backgroundColor: currentOverlay, opacity: currentOverlayOpacity || 0, mixBlendMode: (currentMixBlend as any) || 'multiply' }} />}
                  {currentVignette && <div className="absolute inset-0" style={{ background: 'radial-gradient(circle, transparent 30%, rgba(0,0,0,0.5) 100%)' }} />}
                  {!selectedPreset && <div className="absolute inset-0 flex items-center justify-center bg-black/30"><span className="text-white/80 text-sm font-medium">Select a style →</span></div>}
                </div>

                {/* Shape Previews */}
                <div className="grid grid-cols-3 gap-3 mb-2">
                  {[
                    { label: 'Circle', radius: '50%' },
                    { label: 'Rounded', radius: '16px' },
                    { label: 'Square', radius: '4px' },
                  ].map((shape) => (
                    <div key={shape.label} className="text-center">
                      <div className="w-full aspect-square overflow-hidden bg-gray-100 border border-gray-200" style={{ borderRadius: shape.radius }}>
                        <img src={uploadedImage} alt={shape.label} className="w-full h-full object-cover" style={{ filter: currentFilter }} />
                      </div>
                      <span className="text-[10px] text-gray-400 mt-1 block">{shape.label}</span>
                    </div>
                  ))}
                </div>

                {selectedPreset && (
                  <div className="mt-4 p-3 bg-purple-50 rounded-xl text-center">
                    <span className="text-sm font-semibold text-purple-700">{selectedPreset.name}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Categories Area */}
          <div className="flex-1 min-w-0">
            <div className="space-y-12">
              {categories.slice(0, visibleCategories).map((category) => (
                <div key={category.id}>
                  <div className="flex items-center gap-3 mb-5">
                    <span className="text-2xl">{category.icon}</span>
                    <h3 className="text-lg font-bold text-gray-900">{category.name}</h3>
                    <div className="h-px flex-1 bg-gray-100" />
                    <span className="text-xs text-gray-300 font-medium">{category.presets.length}</span>
                  </div>

                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 xl:grid-cols-6 gap-3">
                    {category.presets.map((preset) => {
                      const isSelected = selectedPreset?.id === preset.id;
                      return (
                        <button
                          key={preset.id}
                          onClick={() => setSelectedPreset(preset)}
                          className={`group relative aspect-square overflow-hidden transition-all duration-200 cursor-pointer ${
                            isSelected
                              ? 'ring-[3px] ring-purple-500 ring-offset-2 shadow-lg scale-[1.03]'
                              : 'hover:scale-[1.04] hover:shadow-md border border-gray-150 hover:border-purple-200'
                          }`}
                          style={{ borderRadius: preset.borderRadius || '16px', border: isSelected ? undefined : (preset.border || undefined) }}
                          title={preset.name}
                        >
                          <img src={uploadedImage} alt={preset.name} className="w-full h-full object-cover" style={{ filter: preset.filter }} />
                          {preset.overlay && <div className="absolute inset-0" style={{ backgroundColor: preset.overlay, opacity: preset.overlayOpacity || 0, mixBlendMode: (preset.mixBlendMode as any) || 'multiply' }} />}
                          {preset.vignette && <div className="absolute inset-0" style={{ background: 'radial-gradient(circle, transparent 30%, rgba(0,0,0,0.5) 100%)' }} />}
                          <div className={`absolute inset-x-0 bottom-0 pt-10 pb-2.5 px-2 transition-opacity duration-200 ${isSelected ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`} style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.7), transparent)' }}>
                            <span className="text-white text-[11px] font-semibold leading-tight block text-center">{preset.name}</span>
                          </div>
                          {isSelected && (
                            <div className="absolute top-1.5 right-1.5 w-5 h-5 bg-purple-600 rounded-full flex items-center justify-center shadow-md">
                              <Check className="w-3 h-3 text-white" strokeWidth={3} />
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}

              {visibleCategories < categories.length && (
                <div className="flex flex-col items-center gap-2 py-6 text-gray-400">
                  <ArrowDown className="w-5 h-5 animate-bounce" />
                  <span className="text-sm font-medium">Scroll for more styles</span>
                  <span className="text-xs">{categories.length - visibleCategories} categories remaining</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
