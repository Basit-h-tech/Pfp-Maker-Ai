'use client';

import { Sparkles, Zap, Heart, Users } from 'lucide-react';
import Card from '@/components/ui/Card';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            About <span className="text-gradient">CreatorVerse AI</span>
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            We're on a mission to empower creators worldwide with powerful AI tools
            and premium resources, all in one beautiful platform.
          </p>
        </div>

        {/* Mission */}
        <div className="mb-20">
          <Card className="max-w-4xl mx-auto">
            <div className="text-center py-8">
              <h2 className="text-3xl font-bold mb-4">Our Mission</h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                CreatorVerse AI was built to solve a simple problem: creators need too many tools.
                We believe design should be accessible, powerful, and fun. That's why we've combined
                AI profile picture creation, premium templates, stunning wallpapers, and a vast
                prompt library into one seamless platform.
              </p>
            </div>
          </Card>
        </div>

        {/* Values */}
        <div className="mb-20">
          <h2 className="text-4xl font-bold text-center mb-12">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Sparkles,
                title: 'Innovation',
                description: 'Pushing boundaries with cutting-edge AI technology',
              },
              {
                icon: Zap,
                title: 'Speed',
                description: 'Fast, efficient tools that save you time',
              },
              {
                icon: Heart,
                title: 'Quality',
                description: 'Premium resources designed by professionals',
              },
              {
                icon: Users,
                title: 'Community',
                description: 'Built for creators, by creators',
              },
            ].map((value, index) => {
              const Icon = value.icon;
              return (
                <Card key={index} hover>
                  <Icon className="w-12 h-12 text-purple-600 mb-4" />
                  <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Team */}
        <div className="text-center">
          <h2 className="text-4xl font-bold mb-6">Join Our Journey</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            CreatorVerse AI is growing every day. Join thousands of creators who trust us
            for their design needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/pfp-studio"
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-xl font-bold shadow-lg hover:shadow-xl transition-all"
            >
              Get Started Free
            </a>
            <a
              href="/contact"
              className="px-8 py-4 bg-white border-2 border-gray-200 hover:border-purple-600 rounded-xl font-bold transition-all"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
