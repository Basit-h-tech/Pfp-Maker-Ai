import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import Navigation from "@/components/layout/Navigation";
import Footer from "@/components/layout/Footer";

export const metadata: Metadata = {
  title: "CreatorVerse - Wallpapers & AI Prompts",
  description: "Premium wallpapers and AI prompts for creators",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased bg-white">
        <Navigation />
        {children}
        <Footer />
      </body>
    </html>
  );
}
