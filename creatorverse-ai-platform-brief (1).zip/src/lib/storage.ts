import { get, set, del, keys } from 'idb-keyval';

// Types
export interface SavedPrompt {
  id: string;
  title: string;
  prompt: string;
  category: string;
  model: string;
  imageUrl: string;
  tags: string[];
  savedAt: number;
}

export interface SavedWallpaper {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  resolution: string;
  savedAt: number;
}

export interface SavedTemplate {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  type: string;
  savedAt: number;
}

export interface Collection {
  id: string;
  name: string;
  description?: string;
  coverImage?: string;
  items: string[];
  type: 'prompt' | 'wallpaper' | 'template' | 'mixed';
  createdAt: number;
}

export interface EditorProject {
  id: string;
  name: string;
  type: 'pfp' | 'design';
  data: any;
  thumbnail?: string;
  createdAt: number;
  updatedAt: number;
}

// Storage keys
const STORAGE_KEYS = {
  FAVORITES_PROMPTS: 'favorites_prompts',
  FAVORITES_WALLPAPERS: 'favorites_wallpapers',
  FAVORITES_TEMPLATES: 'favorites_templates',
  COLLECTIONS: 'collections',
  EDITOR_PROJECTS: 'editor_projects',
  RECENT_SEARCHES: 'recent_searches',
  DOWNLOAD_HISTORY: 'download_history',
};

// Favorites Management
export async function saveFavoritePrompt(prompt: SavedPrompt): Promise<void> {
  const favorites = await getFavoritePrompts();
  const exists = favorites.find(p => p.id === prompt.id);
  if (!exists) {
    await set(STORAGE_KEYS.FAVORITES_PROMPTS, [...favorites, prompt]);
  }
}

export async function removeFavoritePrompt(id: string): Promise<void> {
  const favorites = await getFavoritePrompts();
  await set(STORAGE_KEYS.FAVORITES_PROMPTS, favorites.filter(p => p.id !== id));
}

export async function getFavoritePrompts(): Promise<SavedPrompt[]> {
  return (await get(STORAGE_KEYS.FAVORITES_PROMPTS)) || [];
}

export async function isFavoritePrompt(id: string): Promise<boolean> {
  const favorites = await getFavoritePrompts();
  return favorites.some(p => p.id === id);
}

// Wallpaper Favorites
export async function saveFavoriteWallpaper(wallpaper: SavedWallpaper): Promise<void> {
  const favorites = await getFavoriteWallpapers();
  const exists = favorites.find(w => w.id === wallpaper.id);
  if (!exists) {
    await set(STORAGE_KEYS.FAVORITES_WALLPAPERS, [...favorites, wallpaper]);
  }
}

export async function removeFavoriteWallpaper(id: string): Promise<void> {
  const favorites = await getFavoriteWallpapers();
  await set(STORAGE_KEYS.FAVORITES_WALLPAPERS, favorites.filter(w => w.id !== id));
}

export async function getFavoriteWallpapers(): Promise<SavedWallpaper[]> {
  return (await get(STORAGE_KEYS.FAVORITES_WALLPAPERS)) || [];
}

// Template Favorites
export async function saveFavoriteTemplate(template: SavedTemplate): Promise<void> {
  const favorites = await getFavoriteTemplates();
  const exists = favorites.find(t => t.id === template.id);
  if (!exists) {
    await set(STORAGE_KEYS.FAVORITES_TEMPLATES, [...favorites, template]);
  }
}

export async function removeFavoriteTemplate(id: string): Promise<void> {
  const favorites = await getFavoriteTemplates();
  await set(STORAGE_KEYS.FAVORITES_TEMPLATES, favorites.filter(t => t.id !== id));
}

export async function getFavoriteTemplates(): Promise<SavedTemplate[]> {
  return (await get(STORAGE_KEYS.FAVORITES_TEMPLATES)) || [];
}

// Collections
export async function createCollection(collection: Omit<Collection, 'id' | 'createdAt'>): Promise<Collection> {
  const collections = await getCollections();
  const newCollection: Collection = {
    ...collection,
    id: Date.now().toString(),
    createdAt: Date.now(),
  };
  await set(STORAGE_KEYS.COLLECTIONS, [...collections, newCollection]);
  return newCollection;
}

export async function getCollections(): Promise<Collection[]> {
  return (await get(STORAGE_KEYS.COLLECTIONS)) || [];
}

export async function deleteCollection(id: string): Promise<void> {
  const collections = await getCollections();
  await set(STORAGE_KEYS.COLLECTIONS, collections.filter(c => c.id !== id));
}

// Editor Projects
export async function saveEditorProject(project: Omit<EditorProject, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }): Promise<EditorProject> {
  const projects = await getEditorProjects();
  const now = Date.now();
  
  if (project.id) {
    const index = projects.findIndex(p => p.id === project.id);
    if (index !== -1) {
      projects[index] = { ...project, id: project.id, createdAt: projects[index].createdAt, updatedAt: now } as EditorProject;
      await set(STORAGE_KEYS.EDITOR_PROJECTS, projects);
      return projects[index];
    }
  }
  
  const newProject: EditorProject = {
    ...project,
    id: project.id || now.toString(),
    createdAt: now,
    updatedAt: now,
  } as EditorProject;
  
  await set(STORAGE_KEYS.EDITOR_PROJECTS, [...projects, newProject]);
  return newProject;
}

export async function getEditorProjects(): Promise<EditorProject[]> {
  return (await get(STORAGE_KEYS.EDITOR_PROJECTS)) || [];
}

export async function deleteEditorProject(id: string): Promise<void> {
  const projects = await getEditorProjects();
  await set(STORAGE_KEYS.EDITOR_PROJECTS, projects.filter(p => p.id !== id));
}

// Recent Searches
export async function saveRecentSearch(query: string): Promise<void> {
  const searches = await getRecentSearches();
  const filtered = searches.filter(s => s !== query);
  await set(STORAGE_KEYS.RECENT_SEARCHES, [query, ...filtered].slice(0, 10));
}

export async function getRecentSearches(): Promise<string[]> {
  return (await get(STORAGE_KEYS.RECENT_SEARCHES)) || [];
}

// Download History
export async function saveDownload(item: { id: string; type: string; title: string; timestamp: number }): Promise<void> {
  const history = await getDownloadHistory();
  await set(STORAGE_KEYS.DOWNLOAD_HISTORY, [item, ...history].slice(0, 100));
}

export async function getDownloadHistory(): Promise<any[]> {
  return (await get(STORAGE_KEYS.DOWNLOAD_HISTORY)) || [];
}
