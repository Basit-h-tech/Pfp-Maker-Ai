'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Download, Heart, Eye, Maximize2 } from 'lucide-react';

interface WallpaperCardProps {
  id: string;
  title: string;
  category: string;
  resolution: string;
  imageUrl: string;
  downloads: number;
  tags: string[];
  onFavorite?: (id: string) => void;
  isFavorited?: boolean;
}

export default function WallpaperCard({
  id,
  title,
  category,
  resolution,
  imageUrl,
  downloads,
  tags,
  onFavorite,
  isFavorited = false,
}: WallpaperCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  // Don't render if image failed to load
  if (imageError) {
    return null;
  }

  const handleDownload = () => {
    // In production, this would trigger actual download
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `${title.toLowerCase().replace(/\s/g, '-')}.jpg`;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleFavorite = () => {
    if (onFavorite) {
      onFavorite(id);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="group relative rounded-2xl overflow-hidden bg-white shadow-lg hover:shadow-2xl transition-all duration-300"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{ breakInside: 'avoid' }}
    >
      {/* Image Container */}
      <div className="relative aspect-[4/3] overflow-hidden bg-gray-100">
        {!imageLoaded && (
          <div className="absolute inset-0 animate-pulse bg-gradient-to-br from-purple-100 to-pink-100" />
        )}
        
        <img
          src={imageUrl}
          alt={title}
          className={`w-full h-full object-cover transition-all duration-500 ${
            isHovered ? 'scale-110' : 'scale-100'
          } ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
          onLoad={() => setImageLoaded(true)}
          onError={() => setImageError(true)}
          loading="lazy"
        />

        {/* Gradient Overlay */}
        <div
          className={`absolute inset-0 bg-gradient-to-t from-black/60 via-black/0 to-black/0 transition-opacity duration-300 ${
            isHovered ? 'opacity-100' : 'opacity-0'
          }`}
        />

        {/* Category Badge */}
        <div className="absolute top-3 left-3">
          <span className="px-3 py-1.5 rounded-full bg-white/90 backdrop-blur-sm text-sm font-semibold text-gray-800 shadow-lg">
            {category}
          </span>
        </div>

        {/* Resolution Badge */}
        <div className="absolute top-3 right-3">
          <span className="px-3 py-1.5 rounded-full bg-purple-600/90 backdrop-blur-sm text-sm font-semibold text-white shadow-lg">
            {resolution}
          </span>
        </div>

        {/* Hover Actions */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: isHovered ? 1 : 0, y: isHovered ? 0 : 10 }}
          className="absolute inset-0 flex items-center justify-center space-x-3"
        >
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleDownload}
            className="p-4 bg-white rounded-full shadow-2xl hover:bg-purple-50 transition-colors group/btn"
            title="Download"
          >
            <Download className="w-6 h-6 text-purple-600" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleFavorite}
            className="p-4 bg-white rounded-full shadow-2xl hover:bg-purple-50 transition-colors"
            title={isFavorited ? 'Remove from favorites' : 'Add to favorites'}
          >
            <Heart
              className={`w-6 h-6 transition-colors ${
                isFavorited ? 'fill-red-500 text-red-500' : 'text-purple-600'
              }`}
            />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="p-4 bg-white rounded-full shadow-2xl hover:bg-purple-50 transition-colors"
            title="Full preview"
          >
            <Maximize2 className="w-6 h-6 text-purple-600" />
          </motion.button>
        </motion.div>
      </div>

      {/* Card Footer */}
      <div className="p-5">
        <h3 className="font-bold text-lg text-gray-900 mb-2 line-clamp-1 group-hover:text-purple-600 transition-colors">
          {title}
        </h3>

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-3">
          {tags.slice(0, 3).map((tag) => (
            <span
              key={tag}
              className="px-2 py-1 rounded-lg bg-purple-50 text-purple-700 text-xs font-medium"
            >
              #{tag}
            </span>
          ))}
        </div>

        {/* Stats */}
        <div className="flex items-center justify-between text-sm text-gray-600">
          <div className="flex items-center space-x-1">
            <Download className="w-4 h-4" />
            <span className="font-medium">{downloads.toLocaleString()}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Eye className="w-4 h-4" />
            <span className="font-medium">{(downloads * 3.5).toFixed(0)}</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
