'use client';

import { motion } from 'framer-motion';
import { Zap, Sparkles, Download, Shield, Palette, Users } from 'lucide-react';
import Card from '@/components/ui/Card';

const features = [
  {
    icon: Sparkles,
    title: 'AI-Powered Tools',
    description: 'Create stunning designs with cutting-edge AI technology. From profile pictures to full designs.',
    gradient: 'from-purple-500 to-pink-500',
  },
  {
    icon: Zap,
    title: 'Lightning Fast',
    description: 'Blazing fast performance. Create, edit, and export your designs in seconds, not hours.',
    gradient: 'from-blue-500 to-cyan-500',
  },
  {
    icon: Download,
    title: 'Instant Downloads',
    description: 'Download your creations in high quality. PNG, JPG, WebP - choose your format.',
    gradient: 'from-green-500 to-emerald-500',
  },
  {
    icon: Palette,
    title: 'Professional Quality',
    description: 'Premium templates and resources designed by professional designers for professional results.',
    gradient: 'from-orange-500 to-red-500',
  },
  {
    icon: Shield,
    title: '100% Free to Start',
    description: 'Get started immediately with no credit card required. Access thousands of free resources.',
    gradient: 'from-indigo-500 to-purple-500',
  },
  {
    icon: Users,
    title: 'Join 10K+ Creators',
    description: 'Trusted by thousands of creators, designers, and businesses worldwide.',
    gradient: 'from-pink-500 to-rose-500',
  },
];

export default function FeaturesSection() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Why Choose <span className="text-gradient">CreatorVerse AI</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Everything you need to create stunning designs, all in one powerful platform
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card hover className="h-full">
                  <div
                    className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-6 shadow-lg`}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8"
        >
          {[
            { value: '5000+', label: 'AI Prompts' },
            { value: '1500+', label: 'Templates' },
            { value: '1000+', label: 'Wallpapers' },
            { value: '10K+', label: 'Happy Users' },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-5xl font-bold text-gradient mb-2">{stat.value}</div>
              <div className="text-gray-600 font-medium">{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
