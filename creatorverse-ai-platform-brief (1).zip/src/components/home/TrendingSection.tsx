'use client';

import { motion } from 'framer-motion';
import PromptCard from '@/components/shared/PromptCard';
import WallpaperCard from '@/components/shared/WallpaperCard';
import prompts from '@/data/prompts.json';
import wallpapers from '@/data/wallpapers.json';

export default function TrendingSection() {
  const trendingPrompts = prompts.slice(0, 3);
  const trendingWallpapers = wallpapers.filter(w => w.featured).slice(0, 3);

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-purple-50">
      <div className="container mx-auto px-4">
        {/* Trending Prompts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-4xl font-bold mb-2">
                🔥 <span className="text-gradient">Trending Prompts</span>
              </h2>
              <p className="text-gray-600">Most popular AI prompts this week</p>
            </div>
            <a
              href="/prompts"
              className="px-6 py-3 rounded-xl bg-white border-2 border-gray-200 hover:border-purple-600 hover:bg-purple-50 transition-all font-medium"
            >
              View All →
            </a>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trendingPrompts.map((prompt) => (
              <PromptCard key={prompt.id} {...prompt} />
            ))}
          </div>
        </motion.div>

        {/* Trending Wallpapers */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-4xl font-bold mb-2">
                ✨ <span className="text-gradient">Featured Wallpapers</span>
              </h2>
              <p className="text-gray-600">Stunning 4K wallpapers for your devices</p>
            </div>
            <a
              href="/wallpapers"
              className="px-6 py-3 rounded-xl bg-white border-2 border-gray-200 hover:border-purple-600 hover:bg-purple-50 transition-all font-medium"
            >
              View All →
            </a>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trendingWallpapers.map((wallpaper) => (
              <WallpaperCard key={wallpaper.id} {...wallpaper} />
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
