'use client';

import { motion } from 'framer-motion';
import { Star } from 'lucide-react';
import Card from '@/components/ui/Card';

const testimonials = [
  {
    name: 'Sarah Johnson',
    role: 'Content Creator',
    avatar: '👩‍💼',
    rating: 5,
    text: 'CreatorVerse AI has transformed how I create content. The AI profile picture studio is incredible, and the prompt library saves me hours of work!',
  },
  {
    name: 'Mike Chen',
    role: 'UI/UX Designer',
    avatar: '👨‍💻',
    rating: 5,
    text: 'As a designer, I\'m impressed by the quality of templates and resources. This platform is a game-changer for my workflow.',
  },
  {
    name: 'Emily Rodriguez',
    role: 'YouTuber',
    avatar: '👩‍🎨',
    rating: 5,
    text: 'The wallpapers and thumbnail templates are amazing! I\'ve recommended CreatorVerse AI to all my creator friends.',
  },
  {
    name: 'David Park',
    role: 'Freelancer',
    avatar: '👨‍🎨',
    rating: 5,
    text: 'Everything I need in one place. The quality is professional-grade, and it\'s completely free to start. Absolutely love it!',
  },
  {
    name: 'Lisa Wang',
    role: 'Marketing Manager',
    avatar: '👩‍💼',
    rating: 5,
    text: 'Our team uses CreatorVerse AI daily for social media content. The AI tools are powerful and incredibly easy to use.',
  },
  {
    name: 'James Taylor',
    role: 'Graphic Designer',
    avatar: '👨‍🎤',
    rating: 5,
    text: 'The prompt library alone is worth it. I\'ve discovered so many creative ideas and the results are consistently impressive.',
  },
];

export default function TestimonialsSection() {
  return (
    <section className="py-20 bg-gradient-to-br from-purple-50 to-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Loved by <span className="text-gradient">Creators Worldwide</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Join thousands of designers, creators, and businesses using CreatorVerse AI
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card hover className="h-full">
                {/* Stars */}
                <div className="flex space-x-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                {/* Testimonial Text */}
                <p className="text-gray-700 mb-6 leading-relaxed">"{testimonial.text}"</p>

                {/* Author */}
                <div className="flex items-center space-x-3 pt-4 border-t border-gray-100">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center text-2xl">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <div className="font-bold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-600">{testimonial.role}</div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
