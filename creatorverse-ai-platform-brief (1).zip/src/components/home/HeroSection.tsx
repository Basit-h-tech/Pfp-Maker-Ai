'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, TrendingUp, Sparkles } from 'lucide-react';
import Button from '@/components/ui/Button';
import Link from 'next/link';

const popularSearches = [
  'Gaming Wallpapers',
  'Business Portrait',
  'YouTube Thumbnail',
  'Cyberpunk',
  'Anime',
  'Logo Design',
  'Instagram Post',
  'Minimal',
];

const floatingCards = [
  { id: 1, type: 'prompt', x: '10%', y: '20%', delay: 0 },
  { id: 2, type: 'wallpaper', x: '80%', y: '15%', delay: 0.2 },
  { id: 3, type: 'template', x: '15%', y: '70%', delay: 0.4 },
  { id: 4, type: 'pfp', x: '85%', y: '65%', delay: 0.6 },
];

export default function HeroSection() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchFocused, setSearchFocused] = useState(false);

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-purple-50 via-white to-purple-50">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {floatingCards.map((card) => (
          <motion.div
            key={card.id}
            className="absolute w-32 h-32 rounded-2xl shadow-premium opacity-20"
            style={{
              left: card.x,
              top: card.y,
              background: 'linear-gradient(135deg, #7C3AED, #A855F7)',
            }}
            animate={{
              y: [0, -20, 0],
              rotate: [0, 5, 0],
            }}
            transition={{
              duration: 4,
              delay: card.delay,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-5xl mx-auto text-center"
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-purple-100 text-purple-700 font-medium mb-8"
          >
            <Sparkles className="w-4 h-4" />
            <span>Everything Creators Need. One Platform.</span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-5xl md:text-7xl lg:text-8xl font-bold mb-6 leading-tight"
          >
            Create Beautiful
            <br />
            <span className="text-gradient">AI Designs</span>
            <br />
            Without Limits
          </motion.h1>

          {/* Subheading */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-xl md:text-2xl text-gray-600 mb-12 max-w-3xl mx-auto"
          >
            Professional AI profile pictures, stunning templates, premium wallpapers,
            and powerful prompts — all in one place.
          </motion.p>

          {/* Search Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="max-w-2xl mx-auto mb-8"
          >
            <div
              className={`relative transition-all duration-300 ${
                searchFocused ? 'scale-105 shadow-premium-lg' : 'shadow-premium'
              }`}
            >
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-6 h-6 text-gray-400" />
              <input
                type="text"
                placeholder="Search templates, prompts, wallpapers, profile pictures..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setSearchFocused(false)}
                className="w-full pl-16 pr-6 py-6 rounded-2xl border-2 border-gray-200 focus:border-purple-600 focus:outline-none text-lg bg-white"
              />
            </div>

            {/* Popular Searches */}
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              <span className="text-sm text-gray-500 mr-2">Popular:</span>
              {popularSearches.map((search, index) => (
                <motion.button
                  key={search}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.6 + index * 0.05 }}
                  className="px-4 py-2 rounded-xl bg-white border border-gray-200 hover:border-purple-600 hover:bg-purple-50 transition-all text-sm font-medium text-gray-700 hover:text-purple-600"
                  onClick={() => setSearchQuery(search)}
                >
                  {search}
                </motion.button>
              ))}
            </div>
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <Link href="/pfp-studio">
              <Button size="lg" className="text-lg px-10">
                <Sparkles className="w-5 h-5 mr-2" />
                Start Creating Free
              </Button>
            </Link>
            <Link href="/templates">
              <Button variant="outline" size="lg" className="text-lg px-10">
                Explore Templates
              </Button>
            </Link>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-3xl mx-auto"
          >
            {[
              { label: 'Prompts', value: '5000+' },
              { label: 'Templates', value: '1500+' },
              { label: 'Wallpapers', value: '1000+' },
              { label: 'Users', value: '10K+' },
            ].map((stat, index) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-gradient mb-1">
                  {stat.value}
                </div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Bottom Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent" />
    </section>
  );
}
