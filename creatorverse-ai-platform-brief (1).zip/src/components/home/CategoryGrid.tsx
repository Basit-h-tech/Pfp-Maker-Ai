'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { Sparkles, FileText, Wallpaper, Lightbulb, Palette, Type, Frame, Image } from 'lucide-react';
import Card from '@/components/ui/Card';

const categories = [
  {
    id: 1,
    title: 'AI Profile Pictures',
    description: 'Create stunning profile pictures with AI',
    icon: Sparkles,
    href: '/pfp-studio',
    gradient: 'from-purple-500 to-pink-500',
    size: 'large',
    count: '5000+',
  },
  {
    id: 2,
    title: 'Templates',
    description: 'Professional design templates',
    icon: FileText,
    href: '/templates',
    gradient: 'from-blue-500 to-cyan-500',
    size: 'medium',
    count: '1500+',
  },
  {
    id: 3,
    title: 'Wallpapers',
    description: 'Stunning 4K wallpapers',
    icon: Wallpaper,
    href: '/wallpapers',
    gradient: 'from-green-500 to-emerald-500',
    size: 'medium',
    count: '1000+',
  },
  {
    id: 4,
    title: 'AI Prompts',
    description: 'Premium AI prompts library',
    icon: Lightbulb,
    href: '/prompts',
    gradient: 'from-orange-500 to-red-500',
    size: 'large',
    count: '3000+',
  },
  {
    id: 5,
    title: 'Icons',
    description: 'Beautiful SVG icons',
    icon: Palette,
    href: '/icons',
    gradient: 'from-indigo-500 to-purple-500',
    size: 'small',
    count: '10K+',
  },
  {
    id: 6,
    title: 'Fonts',
    description: 'Premium typography',
    icon: Type,
    href: '/fonts',
    gradient: 'from-pink-500 to-rose-500',
    size: 'small',
    count: '500+',
  },
  {
    id: 7,
    title: 'Mockups',
    description: 'Professional mockups',
    icon: Frame,
    href: '/mockups',
    gradient: 'from-teal-500 to-green-500',
    size: 'small',
    count: '800+',
  },
  {
    id: 8,
    title: 'Backgrounds',
    description: 'Beautiful backgrounds',
    icon: Image,
    href: '/backgrounds',
    gradient: 'from-violet-500 to-purple-500',
    size: 'small',
    count: '2000+',
  },
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
};

export default function CategoryGrid() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Explore Our <span className="text-gradient">Creative Tools</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Everything you need to create stunning designs, all in one platform
          </p>
        </motion.div>

        {/* Bento Grid */}
        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {categories.map((category) => {
            const Icon = category.icon;
            const sizeClasses = {
              large: 'md:col-span-2 md:row-span-2',
              medium: 'md:col-span-1 md:row-span-2',
              small: 'md:col-span-1 md:row-span-1',
            };

            return (
              <motion.div key={category.id} variants={item}>
                <Link href={category.href}>
                  <Card
                    hover
                    className={`group relative overflow-hidden h-full min-h-[200px] ${
                      sizeClasses[category.size as keyof typeof sizeClasses]
                    }`}
                  >
                    {/* Background Gradient */}
                    <div
                      className={`absolute inset-0 bg-gradient-to-br ${category.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}
                    />

                    {/* Icon */}
                    <div
                      className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br ${category.gradient} text-white mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300`}
                    >
                      <Icon className="w-8 h-8" />
                    </div>

                    {/* Content */}
                    <h3 className="text-2xl font-bold mb-2 group-hover:text-purple-600 transition-colors">
                      {category.title}
                    </h3>
                    <p className="text-gray-600 mb-4">{category.description}</p>

                    {/* Count Badge */}
                    <div className="inline-flex items-center px-3 py-1 rounded-full bg-gray-100 text-sm font-medium text-gray-700">
                      {category.count} assets
                    </div>

                    {/* Hover Arrow */}
                    <div className="absolute bottom-6 right-6 opacity-0 group-hover:opacity-100 transform translate-x-2 group-hover:translate-x-0 transition-all duration-300">
                      <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center text-white shadow-lg">
                        →
                      </div>
                    </div>
                  </Card>
                </Link>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
