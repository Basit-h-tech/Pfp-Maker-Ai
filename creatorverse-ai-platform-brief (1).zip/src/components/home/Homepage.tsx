'use client';

import { Sparkles, Upload, Palette, Download, Zap, Shield, Star, ArrowRight, Check } from 'lucide-react';
import Link from 'next/link';

const stats = [
  { value: '200+', label: 'Unique Styles' },
  { value: '42', label: 'Categories' },
  { value: '1024px', label: 'HD Export' },
  { value: 'Free', label: 'No Sign Up' },
];

const features = [
  { icon: Upload, title: 'Upload Any Photo', desc: 'Drag, paste, or click to upload your picture in seconds' },
  { icon: Palette, title: '200+ Pro Styles', desc: 'From vintage to cyberpunk, Taylor Swift to anime — all categories' },
  { icon: Zap, title: 'Instant Preview', desc: 'See every style applied to YOUR face in real-time' },
  { icon: Download, title: 'HD Download', desc: 'Export 1024×1024 HD profile pictures instantly' },
  { icon: Shield, title: '100% Private', desc: 'Everything runs in your browser. No data uploaded anywhere' },
  { icon: Star, title: 'Zero Cost', desc: 'Completely free. No account, no watermark, no limits' },
];

const categoryGroups = [
  { title: 'Color Sets', items: ['Warm', 'Cool', 'Neon', 'Pastel', 'Earth', 'Vibrant', 'Monochrome', 'Sunset', 'Ocean', 'Forest', 'Cherry', 'Lavender', 'Rose Gold', 'Teal'] },
  { title: 'Artistic', items: ['Oil Painting', 'Watercolor', 'Sketch', 'Pop Art', 'Comic', 'Anime', 'Double Exposure'] },
  { title: 'Photo Styles', items: ['Professional', 'Vintage', 'Film Grain', 'HDR', 'Cinematic', 'Moody', 'Minimal'] },
  { title: 'Special', items: ['Taylor Swift Eras', 'Glitch', 'Cyberpunk', 'Neon Portrait', 'Vaporwave', 'Steampunk', 'Fantasy', 'Infrared', 'Noir', 'Mirage'] },
  { title: 'Social Media', items: ['Instagram', 'LinkedIn', 'Twitter/X', 'TikTok', 'Snapchat', 'YouTube', 'Discord', 'Reddit'] },
];

const howItWorks = [
  { step: '01', title: 'Upload Your Photo', desc: 'Drag and drop, paste, or click to upload any picture' },
  { step: '02', title: 'Choose a Style', desc: 'Browse 200+ styles across 42 categories and click to preview' },
  { step: '03', title: 'Download PFP', desc: 'Save your perfect profile picture in HD quality' },
];

export default function Homepage() {
  return (
    <div className="min-h-screen bg-white">
      {/* ============ HERO ============ */}
      <section className="relative overflow-hidden">
        {/* BG Gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-50 via-white to-pink-50" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-purple-200/30 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-pink-200/30 rounded-full blur-3xl" />
        
        <div className="relative max-w-6xl mx-auto px-6 pt-24 pb-20">
          <div className="text-center">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-purple-100 text-purple-700 rounded-full font-semibold text-sm mb-8 border border-purple-200">
              <Sparkles className="w-4 h-4" />
              AI-Powered Profile Picture Maker
            </div>

            {/* Heading */}
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-extrabold text-gray-900 mb-6 leading-[1.05] tracking-tight">
              Create Your<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600">Perfect PFP</span>
            </h1>

            <p className="text-lg md:text-xl text-gray-500 max-w-2xl mx-auto mb-10 leading-relaxed">
              Upload your photo and instantly preview 200+ professional styles.
              From vintage to cyberpunk, Taylor Swift to anime — download in HD, completely free.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <Link
                href="/studio"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-purple-600 hover:bg-purple-700 text-white rounded-2xl font-bold text-lg shadow-xl shadow-purple-600/25 transition-all hover:shadow-2xl hover:shadow-purple-600/30 hover:-translate-y-0.5"
              >
                <Sparkles className="w-5 h-5" />
                Start Creating — Free
              </Link>
              <a
                href="#how-it-works"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white border-2 border-gray-200 hover:border-purple-300 text-gray-700 rounded-2xl font-bold text-lg transition-all hover:-translate-y-0.5"
              >
                See How It Works
                <ArrowRight className="w-5 h-5" />
              </a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-3xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-500 font-medium mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ============ FEATURES ============ */}
      <section className="py-24 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
              Why Creators Love It
            </h2>
            <p className="text-lg text-gray-500">Everything you need, nothing you don't</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <div
                  key={feature.title}
                  className="group p-8 rounded-2xl border border-gray-100 hover:border-purple-200 hover:shadow-lg hover:shadow-purple-100/50 transition-all duration-300"
                >
                  <div className="w-14 h-14 bg-purple-100 group-hover:bg-purple-600 rounded-2xl flex items-center justify-center mb-5 transition-colors duration-300">
                    <Icon className="w-7 h-7 text-purple-600 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-500 leading-relaxed">{feature.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ============ CATEGORIES ============ */}
      <section className="py-24 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
              42 Categories. 200+ Styles.
            </h2>
            <p className="text-lg text-gray-500">Every look you can imagine, all in one place</p>
          </div>

          <div className="space-y-10">
            {categoryGroups.map((group) => (
              <div key={group.title}>
                <h3 className="text-lg font-bold text-gray-900 mb-4">{group.title}</h3>
                <div className="flex flex-wrap gap-2">
                  {group.items.map((item) => (
                    <span
                      key={item}
                      className="px-4 py-2 bg-white border border-gray-200 hover:border-purple-400 hover:bg-purple-50 text-gray-700 hover:text-purple-700 rounded-xl text-sm font-medium cursor-default transition-all"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ HOW IT WORKS ============ */}
      <section id="how-it-works" className="py-24 bg-white">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
              Three Simple Steps
            </h2>
            <p className="text-lg text-gray-500">From photo to perfect PFP in under a minute</p>
          </div>

          <div className="space-y-8">
            {howItWorks.map((item, i) => (
              <div
                key={item.step}
                className="flex items-start gap-6 p-8 rounded-2xl bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-100"
              >
                <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-600/20">
                  <span className="text-white font-extrabold text-xl">{item.step}</span>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-600 text-lg">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ TESTIMONIALS ============ */}
      <section className="py-24 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-4">
              Loved by Creators
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: 'Sarah K.', role: 'Content Creator', text: 'The Taylor Swift styles are incredible! My followers love my new PFPs.', stars: 5 },
              { name: 'Mike R.', role: 'UI Designer', text: 'Finally a tool that has real, usable styles. The professional category is perfect.', stars: 5 },
              { name: 'Emma L.', role: 'YouTuber', text: '200+ styles and they all look amazing on my photo. Downloaded 10 already!', stars: 5 },
            ].map((t) => (
              <div key={t.name} className="p-8 bg-white rounded-2xl border border-gray-100 shadow-sm">
                <div className="flex gap-1 mb-4">
                  {[...Array(t.stars)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 leading-relaxed">"{t.text}"</p>
                <div>
                  <div className="font-bold text-gray-900">{t.name}</div>
                  <div className="text-sm text-gray-500">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ FINAL CTA ============ */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-6">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-purple-600 to-purple-800 p-12 md:p-20 text-center shadow-2xl">
            <div className="absolute top-0 left-1/4 w-64 h-64 bg-purple-500/30 rounded-full blur-3xl" />
            <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-pink-500/20 rounded-full blur-3xl" />
            
            <div className="relative">
              <h2 className="text-4xl md:text-6xl font-extrabold text-white mb-6">
                Ready to Create?
              </h2>
              <p className="text-xl text-purple-200 mb-10 max-w-xl mx-auto">
                Upload your photo and transform it into the perfect profile picture. Free, instant, no sign-up.
              </p>
              <Link
                href="/studio"
                className="inline-flex items-center justify-center gap-2 px-10 py-5 bg-white text-purple-700 rounded-2xl font-bold text-lg shadow-xl hover:shadow-2xl transition-all hover:-translate-y-1"
              >
                <Sparkles className="w-6 h-6" />
                Open PFP Studio
              </Link>
              <div className="mt-8 flex flex-wrap gap-6 justify-center text-purple-200 text-sm">
                <span className="flex items-center gap-1"><Check className="w-4 h-4" /> No account needed</span>
                <span className="flex items-center gap-1"><Check className="w-4 h-4" /> No watermark</span>
                <span className="flex items-center gap-1"><Check className="w-4 h-4" /> 100% free</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
