import Link from 'next/link';
import { Sparkles } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-gray-100 bg-white mt-20">
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg font-bold text-gray-900">CreatorVerse</span>
          </Link>
          <div className="flex items-center gap-6 text-sm text-gray-500">
            <Link href="/studio" className="hover:text-purple-600 transition-colors">PFP Studio</Link>
            <span>·</span>
            <span>© 2024 CreatorVerse AI</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
