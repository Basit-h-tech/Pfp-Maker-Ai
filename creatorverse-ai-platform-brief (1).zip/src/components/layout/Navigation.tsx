'use client';

import Link from 'next/link';
import { Sparkles } from 'lucide-react';

export default function Navigation() {
  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center group-hover:bg-purple-700 transition-colors">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-xl font-extrabold text-gray-900 tracking-tight">CreatorVerse</span>
                <span className="text-[10px] text-gray-400 block -mt-1 font-medium tracking-wider uppercase">PFP Studio</span>
              </div>
            </Link>
            <div className="flex items-center gap-2">
              <Link href="/" className="px-4 py-2 text-gray-600 hover:text-purple-600 font-medium text-sm transition-colors rounded-lg hover:bg-purple-50">
                Home
              </Link>
              <Link
                href="/studio"
                className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-semibold text-sm shadow-md shadow-purple-600/20 transition-all"
              >
                Open Studio
              </Link>
            </div>
          </div>
        </div>
      </nav>
      <div className="h-[72px]" />
    </>
  );
}
