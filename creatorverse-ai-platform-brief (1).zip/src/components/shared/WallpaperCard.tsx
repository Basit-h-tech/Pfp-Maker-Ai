'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Download, Heart, Eye } from 'lucide-react';
import Card from '@/components/ui/Card';
import { saveFavoriteWallpaper, removeFavoriteWallpaper } from '@/lib/storage';

interface WallpaperCardProps {
  id: string;
  title: string;
  category: string;
  resolution: string;
  imageUrl: string;
  downloads: number;
}

export default function WallpaperCard({
  id,
  title,
  category,
  resolution,
  imageUrl,
  downloads,
}: WallpaperCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const handleFavorite = async () => {
    if (isFavorite) {
      await removeFavoriteWallpaper(id);
      setIsFavorite(false);
    } else {
      await saveFavoriteWallpaper({
        id,
        title,
        category,
        resolution,
        imageUrl,
        savedAt: Date.now(),
      });
      setIsFavorite(true);
    }
  };

  const handleDownload = () => {
    // In a real app, this would trigger actual download
    console.log('Downloading:', title);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.3 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <Card hover className="group overflow-hidden p-0">
        {/* Image Container */}
        <div className="relative w-full aspect-video overflow-hidden bg-gradient-to-br from-purple-200 via-pink-200 to-blue-200">
          {/* Placeholder gradient - in production, use real images */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-white/50 text-6xl font-bold">{category}</div>
          </div>

          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: isHovered ? 1 : 0 }}
            className="absolute inset-0 bg-black/60 flex items-center justify-center space-x-3"
          >
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleDownload}
              className="p-4 bg-white rounded-full hover:bg-purple-50 transition-colors shadow-lg"
              title="Download"
            >
              <Download className="w-6 h-6 text-purple-600" />
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleFavorite}
              className="p-4 bg-white rounded-full hover:bg-purple-50 transition-colors shadow-lg"
              title="Favorite"
            >
              <Heart
                className={`w-6 h-6 ${
                  isFavorite ? 'fill-red-500 text-red-500' : 'text-purple-600'
                }`}
              />
            </motion.button>
          </motion.div>

          {/* Category Badge */}
          <div className="absolute top-3 left-3">
            <span className="px-3 py-1 rounded-full bg-white/90 backdrop-blur-sm text-sm font-medium text-gray-800">
              {category}
            </span>
          </div>

          {/* Resolution Badge */}
          <div className="absolute top-3 right-3">
            <span className="px-3 py-1 rounded-full bg-black/50 backdrop-blur-sm text-sm font-medium text-white">
              {resolution}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="font-bold text-lg mb-2 line-clamp-1 group-hover:text-purple-600 transition-colors">
            {title}
          </h3>
          <div className="flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center space-x-1">
              <Download className="w-4 h-4" />
              <span>{downloads.toLocaleString()} downloads</span>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
