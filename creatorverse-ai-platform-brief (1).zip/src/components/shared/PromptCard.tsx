'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Heart, Eye, Download, Check } from 'lucide-react';
import Card from '@/components/ui/Card';
import { saveFavoritePrompt, removeFavoritePrompt } from '@/lib/storage';

interface PromptCardProps {
  id: string;
  title: string;
  prompt: string;
  category: string;
  model: string;
  difficulty: string;
  tags: string[];
  imageUrl: string;
  views: number;
  copies: number;
  saves: number;
}

export default function PromptCard({ 
  id, title, prompt, category, model, difficulty, tags, imageUrl, views, copies, saves 
}: PromptCardProps) {
  const [copied, setCopied] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFavorite = async () => {
    if (isFavorite) {
      await removeFavoritePrompt(id);
      setIsFavorite(false);
    } else {
      await saveFavoritePrompt({
        id,
        title,
        prompt,
        category,
        model,
        imageUrl,
        tags,
        savedAt: Date.now(),
      });
      setIsFavorite(true);
    }
  };

  const difficultyColors = {
    Easy: 'bg-green-100 text-green-700',
    Pro: 'bg-blue-100 text-blue-700',
    Advanced: 'bg-purple-100 text-purple-700',
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
    >
      <Card hover className="group overflow-hidden">
        {/* Image */}
        <div className="relative w-full h-48 mb-4 rounded-xl overflow-hidden bg-gradient-to-br from-purple-100 to-pink-100">
          {imageUrl && (
            <div className="w-full h-full flex items-center justify-center text-gray-400">
              <Sparkles className="w-12 h-12" />
            </div>
          )}
          
          {/* Quick Actions Overlay */}
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center space-x-2">
            <button
              onClick={handleCopy}
              className="p-3 bg-white rounded-xl hover:bg-purple-50 transition-colors"
              title="Copy prompt"
            >
              {copied ? (
                <Check className="w-5 h-5 text-green-600" />
              ) : (
                <Copy className="w-5 h-5 text-gray-700" />
              )}
            </button>
            <button
              onClick={handleFavorite}
              className="p-3 bg-white rounded-xl hover:bg-purple-50 transition-colors"
              title="Save to favorites"
            >
              <Heart
                className={`w-5 h-5 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-700'}`}
              />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="space-y-3">
          {/* Title */}
          <h3 className="font-bold text-lg line-clamp-1 group-hover:text-purple-600 transition-colors">
            {title}
          </h3>

          {/* Badges */}
          <div className="flex flex-wrap gap-2">
            <span className="px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-xs font-medium">
              {model}
            </span>
            <span className={`px-3 py-1 rounded-full text-xs font-medium ${difficultyColors[difficulty as keyof typeof difficultyColors]}`}>
              {difficulty}
            </span>
          </div>

          {/* Prompt Preview */}
          <p className="text-sm text-gray-600 line-clamp-2">{prompt}</p>

          {/* Stats */}
          <div className="flex items-center justify-between text-sm text-gray-500 pt-3 border-t border-gray-100">
            <div className="flex items-center space-x-1">
              <Eye className="w-4 h-4" />
              <span>{views.toLocaleString()}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Copy className="w-4 h-4" />
              <span>{copies.toLocaleString()}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Heart className="w-4 h-4" />
              <span>{saves.toLocaleString()}</span>
            </div>
          </div>

          {/* Copy Button */}
          <button
            onClick={handleCopy}
            className="w-full mt-3 px-4 py-2 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white rounded-xl font-medium transition-all shadow-lg shadow-purple-500/30 hover:shadow-xl hover:shadow-purple-500/40"
          >
            {copied ? 'Copied!' : 'Copy Prompt'}
          </button>
        </div>
      </Card>
    </motion.div>
  );
}

function Sparkles({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
    </svg>
  );
}
